The following is a guide on how to run the iOS application.

Note: A MacOS machine is needed to run the code.

1. Install Xcode 6.3.1 or newer.
2. Double click on 'SportLook.xcworkspace' to open the project
3. Click 'Run' on the iOS simulator, by choosing any device version and an iOS version in the range 7.1 - 8.3.