# Branching model
- Start a new branch from the 'developer' branch
- Make all your commits in this branch
- Create a pull request in the 'developer' branch
- The pull request will be merged into 'developer'
