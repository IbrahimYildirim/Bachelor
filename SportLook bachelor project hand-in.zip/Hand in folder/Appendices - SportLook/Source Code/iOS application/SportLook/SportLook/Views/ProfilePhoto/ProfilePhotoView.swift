//
//  ProfilePhotoView.swift
//  SportLook
//
//  Created by Terminator on 11/03/15.
//  Copyright (c) 2015 BachelorProject. All rights reserved.
//

import UIKit

class ProfilePhotoView: UIView {

    
//    @IBOutlet var vwContent: UIView!
    @IBOutlet weak var imgProfilePhoto: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
//        [[NSBundle mainBundle] loadNibNamed:@"ExpandableStatusView" owner:self options:nil];
//        [self addSubview:_mainView];
        
//        NSBundle.mainBundle().loadNibNamed("ProfilePhotoView", owner: nil, options: nil)[0] as ProfilePhotoView
//        vwContent.addSubview(nameField)
        

        
        
//        imgProfilePhoto.layer.cornerRadius = imgProfilePhoto.frame.size.width / 2
//        imgProfilePhoto.clipsToBounds = true
//        
//        imgProfilePhoto.layer.borderWidth = 3.0
//        imgProfilePhoto.layer.borderColor = UIColor.COLOR_WHITE.CGColor

        
    }

//    required init(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)
//        NSBundle.mainBundle().loadNibNamed("ProfilePhotoView", owner: self, options: nil)
////        self.addSubview(vwContent)
//
//    }

}
