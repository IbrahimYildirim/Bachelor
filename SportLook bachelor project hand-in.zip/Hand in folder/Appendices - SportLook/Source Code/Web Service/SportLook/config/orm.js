module.exports.orm = {
  _hookTimeout: 60000 // I used 60 seconds as my new timeout
};
module.exports.views = {
  _hookTimeout: 60000 // I used 60 seconds as my new timeout
};
module.exports.pubsub = {
  _hookTimeout: 60000 // I used 60 seconds as my new timeout
};
