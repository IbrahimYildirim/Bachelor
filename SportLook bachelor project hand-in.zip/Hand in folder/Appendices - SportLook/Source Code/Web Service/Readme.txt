The following is a guide on how to run the Node.js application

Prerequisites: Install Node.js and npm on your server

Run:
1. Open terminal in the SportLook folder
2. run $ npm install
3. run $ sails lift
4. You should get output telling you this app is running at localhost:1337